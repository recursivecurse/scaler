package synchronization.addersubtractor;

public class Count {

    public Integer value;

    public Count(Integer value){
        this.value = value;
    }

    public  Integer getValue() {
        return value;
    }

    public  void setValue(Integer value) {
        this.value = value;
    }


}